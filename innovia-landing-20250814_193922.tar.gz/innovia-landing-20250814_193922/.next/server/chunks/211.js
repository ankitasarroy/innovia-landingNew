exports.id=211,exports.ids=[211],exports.modules={1550:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a=(0,i(2688).A)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},1860:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a=(0,i(2688).A)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},2704:()=>{},4059:()=>{},4147:()=>{},4421:(e,t,i)=>{"use strict";function a(){return[]}function r(e){}function n(e){let t=[],i={...e,id:`sub-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,subscriptionDate:new Date().toISOString().split("T")[0],status:"active"};return t.push(i),i.id}function o(e,t){let i=[],a=i.findIndex(t=>t.id===e);a>=0&&(i[a].preferences={...i[a].preferences,...t})}function s(e){let t=[],i=t.findIndex(t=>t.id===e);i>=0&&(t[i].status="unsubscribed")}function d(){return[{id:"milestone-template",name:"Milestone Achievement",type:"milestone",subject:"\uD83C\uDFAF Major Milestone: {{title}}",htmlContent:`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>{{title}}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f3f4f6; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
            .header { background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%); padding: 40px 20px; text-align: center; }
            .logo { width: 60px; height: 60px; margin: 0 auto 20px; }
            .header h1 { color: #ffffff; margin: 0; font-size: 28px; font-weight: bold; }
            .content { padding: 40px 20px; }
            .milestone-badge { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600; display: inline-block; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #1f2937; margin-bottom: 16px; }
            .summary { font-size: 16px; color: #6b7280; line-height: 1.6; margin-bottom: 30px; }
            .metrics { display: flex; flex-wrap: wrap; gap: 20px; margin: 30px 0; }
            .metric { background: #f9fafb; padding: 20px; border-radius: 8px; text-align: center; flex: 1; min-width: 120px; }
            .metric-value { font-size: 24px; font-weight: bold; color: #3b82f6; }
            .metric-label { font-size: 14px; color: #6b7280; margin-top: 4px; }
            .achievements { background: #f0fdf4; border-left: 4px solid #10b981; padding: 20px; margin: 30px 0; }
            .achievements h3 { color: #065f46; margin: 0 0 15px 0; font-size: 18px; }
            .achievement { display: flex; align-items: flex-start; margin-bottom: 12px; }
            .achievement-bullet { width: 8px; height: 8px; background: #10b981; border-radius: 50%; margin-top: 6px; margin-right: 12px; flex-shrink: 0; }
            .cta { text-align: center; margin: 40px 0; }
            .cta-button { background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; }
            .footer { background: #1f2937; color: #9ca3af; padding: 30px 20px; text-align: center; font-size: 14px; }
            .footer a { color: #60a5fa; text-decoration: none; }
            .unsubscribe { margin-top: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">
                <img src="{{logoUrl}}" alt="InnovIA Technologies" style="width: 60px; height: 60px;">
              </div>
              <h1>InnovIA Technologies</h1>
            </div>
            
            <div class="content">
              <div class="milestone-badge">🎯 MILESTONE ACHIEVED</div>
              <h2 class="title">{{title}}</h2>
              <p class="summary">{{summary}}</p>
              
              {{#if metrics}}
              <div class="metrics">
                {{#each metrics}}
                <div class="metric">
                  <div class="metric-value">{{value}}</div>
                  <div class="metric-label">{{label}}</div>
                </div>
                {{/each}}
              </div>
              {{/if}}
              
              {{#if achievements}}
              <div class="achievements">
                <h3>Key Achievements</h3>
                {{#each achievements}}
                <div class="achievement">
                  <div class="achievement-bullet"></div>
                  <div>{{this}}</div>
                </div>
                {{/each}}
              </div>
              {{/if}}
              
              <div class="cta">
                <a href="{{readMoreUrl}}" class="cta-button">Read Full Update</a>
              </div>
            </div>
            
            <div class="footer">
              <p>\xa9 2025 InnovIA Technologies. All rights reserved.</p>
              <p>2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada</p>
              <div class="unsubscribe">
                <a href="{{unsubscribeUrl}}">Unsubscribe</a> | 
                <a href="{{preferencesUrl}}">Update Preferences</a>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,textContent:`
🎯 MILESTONE ACHIEVED: {{title}}

{{summary}}

{{#if achievements}}
Key Achievements:
{{#each achievements}}
• {{this}}
{{/each}}
{{/if}}

Read the full update: {{readMoreUrl}}

---
InnovIA Technologies
2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada

Unsubscribe: {{unsubscribeUrl}}
Update Preferences: {{preferencesUrl}}
      `,variables:["title","summary","metrics","achievements","readMoreUrl","logoUrl","unsubscribeUrl","preferencesUrl"]},{id:"progress-template",name:"Progress Update",type:"progress",subject:"\uD83D\uDCC8 Progress Update: {{title}}",htmlContent:`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>{{title}}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f3f4f6; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
            .header { background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%); padding: 40px 20px; text-align: center; }
            .logo { width: 60px; height: 60px; margin: 0 auto 20px; }
            .header h1 { color: #ffffff; margin: 0; font-size: 28px; font-weight: bold; }
            .content { padding: 40px 20px; }
            .progress-badge { background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600; display: inline-block; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #1f2937; margin-bottom: 16px; }
            .summary { font-size: 16px; color: #6b7280; line-height: 1.6; margin-bottom: 30px; }
            .category-tag { background: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; display: inline-block; margin-bottom: 20px; }
            .metrics { display: flex; flex-wrap: wrap; gap: 20px; margin: 30px 0; }
            .metric { background: #f0f9ff; padding: 20px; border-radius: 8px; text-align: center; flex: 1; min-width: 120px; border-left: 4px solid #06b6d4; }
            .metric-value { font-size: 24px; font-weight: bold; color: #0891b2; }
            .metric-label { font-size: 14px; color: #6b7280; margin-top: 4px; }
            .metric-change { font-size: 12px; color: #059669; margin-top: 2px; }
            .cta { text-align: center; margin: 40px 0; }
            .cta-button { background: linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; }
            .footer { background: #1f2937; color: #9ca3af; padding: 30px 20px; text-align: center; font-size: 14px; }
            .footer a { color: #60a5fa; text-decoration: none; }
            .unsubscribe { margin-top: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">
                <img src="{{logoUrl}}" alt="InnovIA Technologies" style="width: 60px; height: 60px;">
              </div>
              <h1>InnovIA Technologies</h1>
            </div>
            
            <div class="content">
              <div class="progress-badge">📈 PROGRESS UPDATE</div>
              <div class="category-tag">{{category}}</div>
              <h2 class="title">{{title}}</h2>
              <p class="summary">{{summary}}</p>
              
              {{#if metrics}}
              <div class="metrics">
                {{#each metrics}}
                <div class="metric">
                  <div class="metric-value">{{value}}</div>
                  <div class="metric-label">{{label}}</div>
                  {{#if change}}<div class="metric-change">{{change}}</div>{{/if}}
                </div>
                {{/each}}
              </div>
              {{/if}}
              
              <div class="cta">
                <a href="{{readMoreUrl}}" class="cta-button">Read Full Update</a>
              </div>
            </div>
            
            <div class="footer">
              <p>\xa9 2025 InnovIA Technologies. All rights reserved.</p>
              <p>2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada</p>
              <div class="unsubscribe">
                <a href="{{unsubscribeUrl}}">Unsubscribe</a> | 
                <a href="{{preferencesUrl}}">Update Preferences</a>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,textContent:`
📈 PROGRESS UPDATE: {{title}}

Category: {{category}}

{{summary}}

{{#if metrics}}
Key Metrics:
{{#each metrics}}
• {{label}}: {{value}} {{#if change}}({{change}}){{/if}}
{{/each}}
{{/if}}

Read the full update: {{readMoreUrl}}

---
InnovIA Technologies
2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada

Unsubscribe: {{unsubscribeUrl}}
Update Preferences: {{preferencesUrl}}
      `,variables:["title","summary","category","metrics","readMoreUrl","logoUrl","unsubscribeUrl","preferencesUrl"]},{id:"announcement-template",name:"Announcement",type:"announcement",subject:"\uD83D\uDCE2 Important Announcement: {{title}}",htmlContent:`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>{{title}}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f3f4f6; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
            .header { background: linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%); padding: 40px 20px; text-align: center; }
            .logo { width: 60px; height: 60px; margin: 0 auto 20px; }
            .header h1 { color: #ffffff; margin: 0; font-size: 28px; font-weight: bold; }
            .content { padding: 40px 20px; }
            .announcement-badge { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600; display: inline-block; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #1f2937; margin-bottom: 16px; }
            .summary { font-size: 16px; color: #6b7280; line-height: 1.6; margin-bottom: 30px; }
            .highlight-box { background: #faf5ff; border-left: 4px solid #8b5cf6; padding: 20px; margin: 30px 0; }
            .highlight-box h3 { color: #6b21a8; margin: 0 0 15px 0; font-size: 18px; }
            .cta { text-align: center; margin: 40px 0; }
            .cta-button { background: linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; }
            .footer { background: #1f2937; color: #9ca3af; padding: 30px 20px; text-align: center; font-size: 14px; }
            .footer a { color: #60a5fa; text-decoration: none; }
            .unsubscribe { margin-top: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">
                <img src="{{logoUrl}}" alt="InnovIA Technologies" style="width: 60px; height: 60px;">
              </div>
              <h1>InnovIA Technologies</h1>
            </div>
            
            <div class="content">
              <div class="announcement-badge">📢 ANNOUNCEMENT</div>
              <h2 class="title">{{title}}</h2>
              <p class="summary">{{summary}}</p>
              
              <div class="highlight-box">
                <h3>What This Means</h3>
                <p>This announcement represents a significant step forward in our AI development journey and demonstrates our commitment to innovation and transparency.</p>
              </div>
              
              <div class="cta">
                <a href="{{readMoreUrl}}" class="cta-button">Read Full Announcement</a>
              </div>
            </div>
            
            <div class="footer">
              <p>\xa9 2025 InnovIA Technologies. All rights reserved.</p>
              <p>2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada</p>
              <div class="unsubscribe">
                <a href="{{unsubscribeUrl}}">Unsubscribe</a> | 
                <a href="{{preferencesUrl}}">Update Preferences</a>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,textContent:`
📢 ANNOUNCEMENT: {{title}}

{{summary}}

What This Means:
This announcement represents a significant step forward in our AI development journey and demonstrates our commitment to innovation and transparency.

Read the full announcement: {{readMoreUrl}}

---
InnovIA Technologies
2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada

Unsubscribe: {{unsubscribeUrl}}
Update Preferences: {{preferencesUrl}}
      `,variables:["title","summary","readMoreUrl","logoUrl","unsubscribeUrl","preferencesUrl"]},{id:"weekly-digest-template",name:"Weekly Digest",type:"digest",subject:"\uD83D\uDCCA Weekly Progress Digest - {{weekOf}}",htmlContent:`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Weekly Progress Digest</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f3f4f6; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
            .header { background: linear-gradient(135deg, #1f2937 0%, #374151 100%); padding: 40px 20px; text-align: center; }
            .logo { width: 60px; height: 60px; margin: 0 auto 20px; }
            .header h1 { color: #ffffff; margin: 0; font-size: 28px; font-weight: bold; }
            .header p { color: #d1d5db; margin: 10px 0 0 0; }
            .content { padding: 40px 20px; }
            .digest-badge { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600; display: inline-block; margin-bottom: 30px; }
            .update-item { border-left: 4px solid #e5e7eb; padding-left: 20px; margin-bottom: 30px; }
            .update-item.milestone { border-left-color: #10b981; }
            .update-item.progress { border-left-color: #06b6d4; }
            .update-item.announcement { border-left-color: #8b5cf6; }
            .update-title { font-size: 18px; font-weight: 600; color: #1f2937; margin-bottom: 8px; }
            .update-summary { font-size: 14px; color: #6b7280; line-height: 1.5; margin-bottom: 10px; }
            .update-meta { font-size: 12px; color: #9ca3af; }
            .stats-grid { display: flex; flex-wrap: wrap; gap: 15px; margin: 30px 0; }
            .stat-item { background: #f9fafb; padding: 15px; border-radius: 8px; text-align: center; flex: 1; min-width: 100px; }
            .stat-value { font-size: 20px; font-weight: bold; color: #3b82f6; }
            .stat-label { font-size: 12px; color: #6b7280; margin-top: 4px; }
            .cta { text-align: center; margin: 40px 0; }
            .cta-button { background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block; }
            .footer { background: #1f2937; color: #9ca3af; padding: 30px 20px; text-align: center; font-size: 14px; }
            .footer a { color: #60a5fa; text-decoration: none; }
            .unsubscribe { margin-top: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">
                <img src="{{logoUrl}}" alt="InnovIA Technologies" style="width: 60px; height: 60px;">
              </div>
              <h1>InnovIA Technologies</h1>
              <p>Weekly Progress Digest</p>
            </div>
            
            <div class="content">
              <div class="digest-badge">📊 WEEKLY DIGEST</div>
              <h2>Week of {{weekOf}}</h2>
              
              <div class="stats-grid">
                <div class="stat-item">
                  <div class="stat-value">{{totalUpdates}}</div>
                  <div class="stat-label">Total Updates</div>
                </div>
                <div class="stat-item">
                  <div class="stat-value">{{milestones}}</div>
                  <div class="stat-label">Milestones</div>
                </div>
                <div class="stat-item">
                  <div class="stat-value">{{progressUpdates}}</div>
                  <div class="stat-label">Progress Updates</div>
                </div>
              </div>
              
              {{#each updates}}
              <div class="update-item {{type}}">
                <div class="update-title">{{title}}</div>
                <div class="update-summary">{{summary}}</div>
                <div class="update-meta">{{category}} • {{date}}</div>
              </div>
              {{/each}}
              
              <div class="cta">
                <a href="{{allUpdatesUrl}}" class="cta-button">View All Updates</a>
              </div>
            </div>
            
            <div class="footer">
              <p>\xa9 2025 InnovIA Technologies. All rights reserved.</p>
              <p>2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada</p>
              <div class="unsubscribe">
                <a href="{{unsubscribeUrl}}">Unsubscribe</a> | 
                <a href="{{preferencesUrl}}">Update Preferences</a>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,textContent:`
📊 WEEKLY PROGRESS DIGEST - Week of {{weekOf}}

This Week's Summary:
• {{totalUpdates}} Total Updates
• {{milestones}} Milestones
• {{progressUpdates}} Progress Updates

{{#each updates}}
{{title}}
{{summary}}
Category: {{category}} • {{date}}

{{/each}}

View all updates: {{allUpdatesUrl}}

---
InnovIA Technologies
2120 Rue Phil Goyette, Vaudreuil-Dorion, QC J7V 3E5, Canada

Unsubscribe: {{unsubscribeUrl}}
Update Preferences: {{preferencesUrl}}
      `,variables:["weekOf","totalUpdates","milestones","progressUpdates","updates","allUpdatesUrl","logoUrl","unsubscribeUrl","preferencesUrl"]}]}function l(e,t){return[].filter(i=>!!("active"===i.status&&i.preferences[e]&&i.preferences.categories.includes(t)))}function c(){return[]}function p(e){}function g(e,t,i){let a=[],r={id:`notif-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,updateId:e,subscriberId:t,templateId:i,status:"pending"};return a.push(r),r.id}function f(e,t){let i=e.subject,a=e.htmlContent,r=e.textContent;Object.entries(t).forEach(([e,t])=>{let n=RegExp(`{{${e}}}`,"g");i=i.replace(n,String(t)),a=a.replace(n,String(t)),r=r.replace(n,String(t))});let n=/{{#if (\w+)}}([\s\S]*?){{\/if}}/g;a=a.replace(n,(e,i,a)=>t[i]?a:""),r=r.replace(n,(e,i,a)=>t[i]?a:"");let o=/{{#each (\w+)}}([\s\S]*?){{\/each}}/g;return a=a.replace(o,(e,i,a)=>{let r=t[i];return Array.isArray(r)?r.map(e=>{let t=a;return"object"==typeof e?Object.entries(e).forEach(([e,i])=>{let a=RegExp(`{{${e}}}`,"g");t=t.replace(a,String(i))}):t=t.replace(/{{this}}/g,String(e)),t}).join(""):""}),r=r.replace(o,(e,i,a)=>{let r=t[i];return Array.isArray(r)?r.map(e=>{let t=a;return"object"==typeof e?Object.entries(e).forEach(([e,i])=>{let a=RegExp(`{{${e}}}`,"g");t=t.replace(a,String(i))}):t=t.replace(/{{this}}/g,String(e)),t}).join(""):""}),{subject:i,htmlContent:a,textContent:r}}async function u(e,t,i,a){return(await new Promise(e=>setTimeout(e,1e3)),Math.random()>.05)?(console.log(`📧 Email sent to ${e}: ${t}`),{success:!0,messageId:`msg-${Date.now()}-${Math.random().toString(36).substr(2,9)}`}):(console.error(`❌ Failed to send email to ${e}: ${t}`),{success:!1,error:"SMTP connection failed"})}function m(e,t){let i=[],a=i.findIndex(t=>t.id===e);a>=0&&(i[a].status="sent",i[a].sentAt=new Date().toISOString())}function h(e,t){let i=[],a=i.findIndex(t=>t.id===e);a>=0&&(i[a].status="failed",i[a].errorMessage=t)}function b(e){return`${window.location.origin}/unsubscribe?id=${e}`}function x(e){return`${window.location.origin}/email-preferences?id=${e}`}i.d(t,{Bq:()=>s,Bt:()=>g,Db:()=>x,EJ:()=>b,EO:()=>h,QQ:()=>n,SQ:()=>d,ZM:()=>u,de:()=>m,eY:()=>o,l:()=>l,p4:()=>c,qE:()=>f,q_:()=>a})},4934:(e,t,i)=>{"use strict";i.d(t,{$:()=>d});var a=i(687);i(3210);var r=i(1329),n=i(4224),o=i(6241);let s=(0,n.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",{variants:{variant:{default:"bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",destructive:"bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",outline:"border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",secondary:"bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-9 px-4 py-2 has-[>svg]:px-3",sm:"h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",lg:"h-10 rounded-md px-6 has-[>svg]:px-4",icon:"size-9"}},defaultVariants:{variant:"default",size:"default"}});function d({className:e,variant:t,size:i,asChild:n=!1,...d}){let l=n?r.DX:"button";return(0,a.jsx)(l,{"data-slot":"button",className:(0,o.cn)(s({variant:t,size:i,className:e})),...d})}},5192:(e,t,i)=>{"use strict";i.d(t,{BT:()=>l,Wu:()=>c,ZB:()=>d,Zp:()=>o,aR:()=>s});var a=i(687),r=i(3210),n=i(6241);let o=r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("div",{ref:i,className:(0,n.cn)("rounded-lg border bg-card text-card-foreground shadow-sm",e),...t}));o.displayName="Card";let s=r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("div",{ref:i,className:(0,n.cn)("flex flex-col space-y-1.5 p-6",e),...t}));s.displayName="CardHeader";let d=r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("h3",{ref:i,className:(0,n.cn)("text-2xl font-semibold leading-none tracking-tight",e),...t}));d.displayName="CardTitle";let l=r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("p",{ref:i,className:(0,n.cn)("text-sm text-muted-foreground",e),...t}));l.displayName="CardDescription";let c=r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("div",{ref:i,className:(0,n.cn)("p-6 pt-0",e),...t}));c.displayName="CardContent",r.forwardRef(({className:e,...t},i)=>(0,a.jsx)("div",{ref:i,className:(0,n.cn)("flex items-center p-6 pt-0",e),...t})).displayName="CardFooter"},5633:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>l,metadata:()=>d});var a=i(7413),r=i(848),n=i.n(r),o=i(6680),s=i.n(o);i(2704);let d={title:"v0 App",description:"Created with v0",generator:"v0.dev"};function l({children:e}){return(0,a.jsxs)("html",{lang:"en",children:[(0,a.jsx)("head",{children:(0,a.jsx)("style",{children:`
html {
  font-family: ${n().style.fontFamily};
  --font-sans: ${n().variable};
  --font-mono: ${s().variable};
}
        `})}),(0,a.jsx)("body",{children:e})]})}},6120:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,6346,23)),Promise.resolve().then(i.t.bind(i,7924,23)),Promise.resolve().then(i.t.bind(i,5656,23)),Promise.resolve().then(i.t.bind(i,99,23)),Promise.resolve().then(i.t.bind(i,8243,23)),Promise.resolve().then(i.t.bind(i,8827,23)),Promise.resolve().then(i.t.bind(i,2763,23)),Promise.resolve().then(i.t.bind(i,7173,23))},6241:(e,t,i)=>{"use strict";i.d(t,{cn:()=>n});var a=i(9384),r=i(2348);function n(...e){return(0,r.QP)((0,a.$)(e))}},6392:(e,t,i)=>{Promise.resolve().then(i.t.bind(i,6444,23)),Promise.resolve().then(i.t.bind(i,6042,23)),Promise.resolve().then(i.t.bind(i,8170,23)),Promise.resolve().then(i.t.bind(i,9477,23)),Promise.resolve().then(i.t.bind(i,9345,23)),Promise.resolve().then(i.t.bind(i,2089,23)),Promise.resolve().then(i.t.bind(i,6577,23)),Promise.resolve().then(i.t.bind(i,1307,23))}};